class PyGameRenderer:
    def __init__(self):
        pass

class AtraJaxisRenderer:
    def __init__(self):
        pass
