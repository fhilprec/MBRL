Freeway Environment
===================

.. automodule:: jaxatari.games.jax_freeway
   :members:
   :undoc-members:
   :show-inheritance:
