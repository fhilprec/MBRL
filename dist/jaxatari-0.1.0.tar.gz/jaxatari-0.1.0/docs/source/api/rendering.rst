Rendering
=========

The rendering subpackage handles visualization and sprite-based rendering of object-centric environments.

.. automodule:: jaxatari.rendering.atraJaxis
   :members:
   :undoc-members:
   :show-inheritance:
