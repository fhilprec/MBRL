pip install build
python -m build
pip install .