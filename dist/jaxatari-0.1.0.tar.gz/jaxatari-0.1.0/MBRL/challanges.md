didnt have a reward model at first -> have to learn a reward model alongside the worldmodel
I am using obs_to_flat_array -> is learning on objects but maybe not object centric how are you doing that?

Okay first try PPO to do something reasonable in seaquest
then try again using world model since i have no way to know for sure how good the worldmodel is

after increasing steps agent had bigger return but during rendering why?



ssh-add ~/ssh/Github